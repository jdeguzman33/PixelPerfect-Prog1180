document.getElementById("registration-form").addEventListener("submit", function (e) {
    e.preventDefault();


    const id = document.getElementById("ID").value;
    const firstName = document.getElementById("first-name").value;
    const lastName = document.getElementById("last-name").value;
    const email = document.getElementById("email").value;
    const address = document.getElementById("address").value;
    const postalCode = document.getElementById("postal-code").value;
    const province = document.getElementById("province").value;
    const city = document.getElementById("city").value;
    const phone = document.getElementById("phone").value;
    const phonePattern = /^\d{3}-\d{3}-\d{4}$/;
    if (phonePattern.test(phone)) {
        alert("Valid phone number: " + phone);
    } else {
        alert("Invalid phone number. Please use the format '000-000-0000'.");
    }

    
        const formData = {
            ID: id,
            "First Name": firstName,
            "Last Name": lastName,
            Email: email,
            Address: address,
            "Postal Code": postalCode,
            Province: province,
            City: city,
            Phone: phone
        };

       


    alert("Thank you !\n\n" +
        "ID: " + formData.ID + "\n" +
        "First Name: " + formData["First Name"] + "\n" +
        "Last Name: " + formData["Last Name"] + "\n" +
        "Email: " + formData.Email + "\n" +
        "Address: " + formData.Address + "\n" +
        "Postal Code: " + formData["Postal Code"] + "\n" +
        "Province: " + formData.Province + "\n" +
        "City: " + formData.City + "\n" +
        "Phone: " + formData.Phone);
});