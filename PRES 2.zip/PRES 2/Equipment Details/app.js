// Get a reference to the form element
const equipmentForm = document.querySelector('form');

// Function to validate the form
function validateForm() {
    const equipmentName = document.getElementById('equipmentName').value.trim();
    const serialNumber = document.getElementById('serialNumber').value.trim();
    const manufacturer = document.getElementById('manufacturer').value.trim();
    const model = document.getElementById('model').value.trim();
    const colour = document.getElementById('colour').value.trim();

    // Perform validation checks here
    if (equipmentName === '') {
        alert('Equipment Name is required.');
        return false;
    } else if (serialNumber === '') {
        alert('Serial Number is required.');
        return false;
    } else if (serialNumber.length < 6) {
        alert('Serial Number should have at least 6 characters.');
        return false;
    } else if (!/^[A-Z0-9]+$/.test(serialNumber)) {
        alert('Serial Number should only contain uppercase letters and numbers.');
        return false;
    } else if (manufacturer === '') {
        alert('Manufacturer is required.');
        return false;
    } else if (model === '') {
        alert('Model is required.');
        return false;
    } else if (colour === '') {
        alert('Colour is required.');
        return false;
    }

    // Additional validation checks can be added as needed
    
    return true;
}

// Event listener for form submission
equipmentForm.addEventListener('submit', function (e) {
    e.preventDefault(); // Prevent the default form submission
    
    // Validate the form
    if (validateForm()) {
        // Form is valid, you can submit it to the server or perform other actions
        alert('Equipment Registered!');
        // You can add code here to send the form data to the server if needed
    }
});
